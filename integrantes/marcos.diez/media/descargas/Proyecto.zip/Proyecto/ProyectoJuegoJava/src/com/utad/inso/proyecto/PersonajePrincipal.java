package com.utad.inso.proyecto;

public class PersonajePrincipal implements Personajes {
	private Integer resistencia;
	private Integer vida;
	private Integer agilidad;
	private Integer fuerza;
	private String nombre;
	private Estado estado;
	private Arma arma;
	private Arquetipo arquetipo;
	private Integer turnosEstadoAplicado;
	
	public void CambiarArma(AbstractEnemySpawnerFactory mundo ) {
		if(mundo instanceof World2Spawner) {
			switch(arquetipo) {
				case FUERTE:{
					setArma(new ArmaDecoradorPoderI(arma, "Cachiporra electrica", 10, ElementoArma.ELECTRICO));
					break;
				}
				case AGIL:{
					setArma(new ArmaDecoradorPoderI(arma, "Arco fogoso", 9, ElementoArma.FUEGO));
					break;
				}
				case EQUILIBRADO:{
					setArma(new ArmaDecoradorPoderI(arma, "Espada corta azul", 10, ElementoArma.HIELO));
					break;
				}
			}
		} else if(mundo instanceof World3Spawner) {
			switch(arquetipo) {
			case FUERTE:{
				setArma(new ArmaDecoradorPoderII(arma, "Cachiporra magica de la muerte", 20, ElementoArma.SUENIO));
				break;
			}
			case AGIL:{
				setArma(new ArmaDecoradorPoderII(arma, "Arco de rapid fire con heces", 19, ElementoArma.VENENO));
				break;
			}
			case EQUILIBRADO:{
				setArma(new ArmaDecoradorPoderII(arma, "Espada con soplete en la punta", 20, ElementoArma.FUEGO));
				break;
			}
		}
	}
	}
	
	public String layout() {
		return "\nNombre: " + nombre + "\nArma: " + arma.getDescripcion() +"\tElemento: "+ arma.getElementoArma() + "\nVida: " + vida + "\tEstado: "+ estado;
	}
	
	public PersonajePrincipal(String nombre, Integer resistencia, Integer vida, Integer agilidad, Integer fuerza,Arma arma, Arquetipo arquetipo){
		this.setNombre(nombre);
		this.setAgilidad(agilidad);
		this.setFuerza(fuerza);
		this.setResistencia(resistencia);
		this.setVida(vida);
		this.setArma(arma);
		this.setEstado(Estado.PERFECTO);
		this.setArquetipo(arquetipo);
		this.setTurnosEstadoAplicado(0);
		
	}
	public Integer getResistencia() {
		return resistencia;
	}
	public void setResistencia(Integer resistencia) {
		this.resistencia = resistencia;
	}
	public Integer getVida() {
		return vida;
	}
	public void setVida(Integer vida) {
		this.vida = vida;
	}
	public Integer getAgilidad() {
		return agilidad;
	}
	public void setAgilidad(Integer agilidad) {
		this.agilidad = agilidad;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public Integer getFuerza() {
		return fuerza;
	}
	public void setFuerza(Integer fuerza) {
		this.fuerza = fuerza;
	}
	public Estado getEstado() {
		return estado;
	}
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	public Arma getArma() {
		return arma;
	}
	public void setArma(Arma arma) {
		this.arma = arma;
	}

	public Arquetipo getArquetipo() {
		return arquetipo;
	}

	public void setArquetipo(Arquetipo arquetipo) {
		this.arquetipo = arquetipo;
	}

	public Integer getTurnosEstadoAplicado() {
		return turnosEstadoAplicado;
	}

	public void setTurnosEstadoAplicado(Integer turnosEstadoAplicado) {
		this.turnosEstadoAplicado = turnosEstadoAplicado;
	}
}
