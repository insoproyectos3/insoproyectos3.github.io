package com.utad.inso.proyecto;

public class WorldManager {
	private World1Spawner world1Spawner = new World1Spawner();
	private World2Spawner world2Spawner = new World2Spawner();
	private World3Spawner world3Spawner = new World3Spawner();
	private World4Spawner world4Spawner = new World4Spawner();
	private AbstractEnemySpawnerFactory spawner = world1Spawner;
	private WorldManager() {
		super();
	}
	private static WorldManager Instance = new WorldManager();
	public static WorldManager getInstance() {
		return Instance;
	}
	
	public void updateWorld() {
		if(spawner instanceof World1Spawner)
			this.spawner=world2Spawner;
		else if(spawner instanceof World2Spawner)
			this.spawner=world3Spawner;
		else if(spawner instanceof World3Spawner)
			this.spawner=world4Spawner;
		else
			this.spawner=world1Spawner;
	}
	public void setArmas(Arma armaDemonio,Arma armaBruja,Arma armaFantasma) {
		((DemonWitchGhostAbstractFactory) this.spawner).setArmas(armaDemonio,armaBruja,armaFantasma);
	}
	public void setArmaDemonio(Arma arma) {
		((DemonWitchGhostAbstractFactory) this.spawner).setArmaDemonio(arma);
	}
	public void setArmaBruja(Arma arma) {
		((DemonWitchGhostAbstractFactory) this.spawner).setArmaBruja(arma);
	}
	public void setArmaFantasma(Arma arma) {
		((DemonWitchGhostAbstractFactory) this.spawner).setArmaFantasma(arma);
	}
	public Enemigo createEnemy() {
		return this.spawner.createEnemy();
	}
	
	public AbstractEnemySpawnerFactory getSpawner() {
		return this.spawner;
	}
	
	public Ogro elBoss() {
		Arma armaBoss = new ArmaEstandar("Palo",20,ElementoArma.BASICO);
		armaBoss = new ArmaDecoradorPoderII(armaBoss, "Palo duro", 21, ElementoArma.SUENIO);
		return new Ogro( "Estefani",  100, 500, 20, 30, EstadosEstrategia.AGRESIVO,armaBoss );
	}
}

