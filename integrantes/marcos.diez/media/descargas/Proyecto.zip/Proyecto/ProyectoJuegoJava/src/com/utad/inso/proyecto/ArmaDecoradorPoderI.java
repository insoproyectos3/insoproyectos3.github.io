package com.utad.inso.proyecto;

public class ArmaDecoradorPoderI implements ArmaDecorator{
	
	private Integer danio;
	private String descripcion;
	private Arma armaDecorador;
	private ElementoArma elemento;
	
	public ArmaDecoradorPoderI(Arma arma,String descripcion,Integer danio,ElementoArma elemento) {
		this.armaDecorador = arma;
		this.descripcion = descripcion;
		this.danio = danio;
		this.elemento = elemento;
	}

	public Arma getArma() {
		return this.armaDecorador;
	}

	public String getDescripcion() {
		return "["+this.descripcion+"]";
	}

	public Integer getDanio() {
		return this.danio;
	}

	public void setArma(Arma arma) {
		this.armaDecorador = arma;
	}

	public ElementoArma getElementoArma() {
		return this.elemento;
	}
	
}