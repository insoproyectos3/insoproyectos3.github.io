package com.utad.inso.proyecto;

public enum Estadisticas {
	
	Demonio(2,100,1,7),Fantasma(5,70,10,8),Ogro(10,200,2,15),Bruja(1,80,5,10);
	
	private final Integer resistencia;
	private final Integer vida;
	private final Integer agilidad;
	private final Integer fuerza;
	
	private Estadisticas(Integer resistencia,Integer vida,Integer agilidad,Integer fuerza){
		this.agilidad = agilidad;
		this.fuerza = fuerza;
		this.resistencia = resistencia;
		this.vida = vida;
	}

	public Integer getResistencia() {
		return resistencia;
	}

	public Integer getVida() {
		return vida;
	}

	public Integer getAgilidad() {
		return agilidad;
	}

	public Integer getFuerza() {
		return fuerza;
	}
	
}
