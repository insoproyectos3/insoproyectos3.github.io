package com.utad.inso.proyecto;

public class GameController {
	private static GameController gameController = new GameController();
	public static GameController getInstance(){
		return gameController;
	}
	
	private GameController(){}
	
	private void modificacionesPorCambioDeMundo(PersonajePrincipal heroe, WorldManager mundos, Arma armaDemonio, Arma armaBruja, Arma armaFantasma) {
		mundos.updateWorld();
		heroe.CambiarArma(mundos.getSpawner());
		mundos.setArmas(armaDemonio,armaBruja,armaFantasma);
	}
	
	public void iniciarJuego() {
		
		int contadorBatallas = 0;
		Arma armaDemonio = new ArmaEstandar("Tridente",5,ElementoArma.FUEGO);
		Arma armaBruja = new ArmaEstandar("Varita",3,ElementoArma.VENENO);
		Arma armaFantasma = new ArmaEstandar("Aliento fantasmal",5,ElementoArma.FUEGO);
		boolean victoria = true;
		PersonajePrincipal heroe = MenuPersonalizacionPersonaje.crearPersonaje();
		Enemigo enemigo;
		
		WorldManager mundos = WorldManager.getInstance();
		mundos.setArmas(armaDemonio,armaBruja,armaFantasma);
			
		while(contadorBatallas<12&&victoria) {
			
			contadorBatallas++;
			
			enemigo = mundos.createEnemy();
			
			victoria = Combate.getInstance().combate(heroe,enemigo);
			
			
			if(contadorBatallas%4==0) {
				if(mundos.getSpawner() instanceof World1Spawner) {
					armaBruja = new ArmaDecoradorPoderI(armaBruja, "Varita encantada", 7, ElementoArma.HIELO);
					armaDemonio = new ArmaDecoradorPoderI(armaFantasma,"Tridente incandescente",10,ElementoArma.FUEGO);
					armaFantasma = new ArmaDecoradorPoderI(armaFantasma, "Espada fantasmal", 8, ElementoArma.SUENIO);
					
				}else if(mundos.getSpawner() instanceof World2Spawner){
					armaBruja = new ArmaDecoradorPoderII(armaBruja, "Varita Suprema", 11, ElementoArma.ELECTRICO);
					armaDemonio = new ArmaDecoradorPoderII(armaFantasma,"Destructor de mundos",14,ElementoArma.ELECTRICO);
					armaFantasma = new ArmaDecoradorPoderII(armaFantasma, "Navaja fantasmal", 12, ElementoArma.SUENIO);
					
				}
				if(contadorBatallas!=12) {
					modificacionesPorCambioDeMundo(heroe, mundos, armaDemonio, armaBruja, armaFantasma);
				}
			}
			System.out.print("\nCOMBATE TERMINADO\n");
			
		}
		if(victoria) {
			mundos.updateWorld();
			enemigo = mundos.createEnemy();
			Combate.getInstance().combate(heroe,enemigo);
		}else {
			System.out.print("\nMuerto (Tu)\n");
		}
		
	}
	
	
}
