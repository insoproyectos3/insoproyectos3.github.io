package com.utad.inso.proyecto;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MenuPersonalizacionPersonaje {
	private static MenuPersonalizacionPersonaje menu = new MenuPersonalizacionPersonaje();

	public static MenuPersonalizacionPersonaje getInstance(){
		return menu;
	}
	
	private static PersonajePrincipal personaje;
	
	private MenuPersonalizacionPersonaje(){
		super();
	}

	public static PersonajePrincipal crearPersonaje() {
		int menu=0;
		String nombre;
		Scanner entrada= new Scanner(System.in);
		boolean error;
		
		do{
			error = false;
			System.out.println("�Como se llama tu personaje?");
			nombre=entrada.next();
			
			System.out.println("��ELIJAMOS PEROSONAJE PRINCIPAL!!"
					+ "\n 1-)Fuerte-> Vida:[200] Fuerza:[30] Agilidad:[15] Resistencia:[25]"
					+ "\n 2-)Agil-> Vida:[120] Fuerza:[15] Agilidad:[40] Resistencia:[15]"
					+ "\n 3-)Compensado-> Vida:[150] Fuerza:[20] Agilidad:[20] Resistencia:[20]"
					+ "\nIntroduce:");
			try {
				menu=entrada.nextInt();
			}catch(InputMismatchException exception) {
				System.out.println("Valor introducido incorrecto no es un valor entero");
				error = true;
			}
		
			switch(menu) {
				case 1:
					System.out.println("Has elegido un personaje fuertaco");
					personaje= new PersonajePrincipal(nombre,25,200,15,30,new ArmaEstandar("Cachiporra",10,ElementoArma.BASICO),Arquetipo.FUERTE);
					break;
				case 2:
					System.out.println("Has elegido un personaje agil");
					personaje= new PersonajePrincipal(nombre,15,120,40,15,new ArmaEstandar("Arco",10 ,ElementoArma.BASICO),Arquetipo.AGIL);
					break;
				case 3:
					System.out.println("Has elegido un personaje compensado");
					personaje= new PersonajePrincipal(nombre,20,150,20,20,new ArmaEstandar("Espada",10,ElementoArma.BASICO),Arquetipo.EQUILIBRADO);
					break;
	
				default:{
					System.out.println("El menu no tiene tantos valores");
					error = true;
				}
					
			}
		}while(error);
		
		return personaje;	
	}
}
