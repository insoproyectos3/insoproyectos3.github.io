package com.utad.inso.proyecto;

public interface MovimientosEnemigo extends EnemigoTemplate{
	public void GeneraMovimientos();
}
