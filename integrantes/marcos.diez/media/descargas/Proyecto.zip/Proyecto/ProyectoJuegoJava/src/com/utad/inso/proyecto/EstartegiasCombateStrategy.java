package com.utad.inso.proyecto;

public interface EstartegiasCombateStrategy{
	public EstadosEstrategia getEstrategiaCombate();
}
