package com.utad.inso.proyecto;

import java.util.ArrayList;

public class Ogro implements Enemigo,MovimientosEnemigo {
	private Integer resistencia;
	private Integer vida;
	private Integer agilidad;
	private Integer fuerza;
	private String nombre;
	private Estado estado;
	private EstadosEstrategia estadoEstrategia;
	private Arma arma;
	private Integer turnosEstadoAplicado;
	private ArrayList<ECombate> movimientos = new ArrayList<ECombate>();

	Ogro(String nombre, Integer resistencia, Integer vida, Integer agilidad, Integer fuerza, EstadosEstrategia estadoEstrategia, Arma arma){
		this.setNombre(nombre);
		this.setAgilidad(agilidad);
		this.setFuerza(fuerza);
		this.setResistencia(resistencia);
		this.setVida(vida);
		this.setEstado(Estado.PERFECTO);
		this.setTurnosEstadoAplicado(0);
		this.setEstadoEstrategia(estadoEstrategia);
		this.setArma(arma);
		this.combate();
	}

	public String layout() {
		return "\nNombre:" + nombre + "\tEstrategia:" + estadoEstrategia + "\nArma:" + arma.getDescripcion() +"\tElemento:"+ arma.getElementoArma() + "\nVida:" + vida + "\tEstado:"+ estado;
	}
	
	public String getNombre() {
		return nombre;
	}

	public Integer getVida() {
		return vida;
	}

	public Integer getAgilidad() {
		return agilidad;
	}

	public Integer getFuerza() {
		return fuerza;
	}

	public Integer getResistencia() {
		return resistencia;
	}
	
	public Estado getEstado() {
		return estado;
	}

	public EstadosEstrategia getEstadoEstrategia() {
		return estadoEstrategia;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setFuerza(Integer fuerza) {
		this.fuerza = fuerza;
	}

	public void setAgilidad(Integer agilidad) {
		this.agilidad = agilidad;
	}
	
	public void setVida(Integer vida) {
		this.vida = vida;
	}
	
	public void setResistencia(Integer resistencia) {
		this.resistencia = resistencia;
	}
	
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	
	public void setEstadoEstrategia(EstadosEstrategia estadoEstrategia) {
		this.estadoEstrategia = estadoEstrategia;
	}

	public Arma getArma() {
		return arma;
	}

	public void setArma(Arma arma) {
		this.arma = arma;
	}
	
	public ArrayList<ECombate> getMovimientos() {
		return movimientos;
	}

	public void setMovimientos(ArrayList<ECombate> movimientos) {
		this.movimientos = movimientos;
	}
	
	public void GeneraMovimientos() {
		
		if(estadoEstrategia==EstadosEstrategia.AGRESIVO) {
			movimientos.add(ECombate.ATACAR);
			movimientos.add(ECombate.ATACAR);
			movimientos.add(ECombate.DEFENDER);
			movimientos.add(ECombate.ATACAR);
		}else if(estadoEstrategia==EstadosEstrategia.DEFENSIVO) {
			movimientos.add(ECombate.DEFENDER);
			movimientos.add(ECombate.ATACAR);
			movimientos.add(ECombate.DEFENDER);
			movimientos.add(ECombate.DEFENDER);
		}else {
			movimientos.add(ECombate.DEFENDER);
			movimientos.add(ECombate.ATACAR);
			movimientos.add(ECombate.DEFENDER);
			movimientos.add(ECombate.ATACAR);
		}
	}

	public void combate() {
		this.GeneraMovimientos();
	}

	public Integer getTurnosEstadoAplicado() {
		return turnosEstadoAplicado;
	}

	public void setTurnosEstadoAplicado(Integer turnosEstadoAplicado) {
		this.turnosEstadoAplicado = turnosEstadoAplicado;
	}

}
