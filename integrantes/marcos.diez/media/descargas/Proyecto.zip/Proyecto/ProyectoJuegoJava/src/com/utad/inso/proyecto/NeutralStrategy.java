package com.utad.inso.proyecto;

public class NeutralStrategy implements EstartegiasCombateStrategy{
	
	public EstadosEstrategia getEstrategiaCombate() {
		return EstadosEstrategia.NEUTRAL;
	}
}
