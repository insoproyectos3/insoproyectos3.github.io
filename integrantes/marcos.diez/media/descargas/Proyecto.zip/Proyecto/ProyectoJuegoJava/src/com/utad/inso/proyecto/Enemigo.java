package com.utad.inso.proyecto;

import java.util.ArrayList;

public interface Enemigo extends Personajes,MovimientosEnemigo{
	public EstadosEstrategia getEstadoEstrategia();
	public ArrayList<ECombate> getMovimientos();
}
