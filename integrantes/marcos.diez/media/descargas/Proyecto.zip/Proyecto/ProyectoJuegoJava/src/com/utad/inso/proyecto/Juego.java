package com.utad.inso.proyecto;

public class Juego {
	public static void main(String[] args) {
		GameController game = GameController.getInstance();
		game.iniciarJuego();		
	}
}
