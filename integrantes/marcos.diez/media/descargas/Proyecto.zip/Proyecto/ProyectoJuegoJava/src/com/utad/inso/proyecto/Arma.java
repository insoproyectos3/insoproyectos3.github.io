package com.utad.inso.proyecto;

public interface Arma {
	public String getDescripcion();
	public Integer getDanio();
	public ElementoArma getElementoArma();
}
