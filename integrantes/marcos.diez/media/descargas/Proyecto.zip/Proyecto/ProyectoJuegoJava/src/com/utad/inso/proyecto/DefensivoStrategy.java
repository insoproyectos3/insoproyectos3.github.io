package com.utad.inso.proyecto;

public class DefensivoStrategy implements EstartegiasCombateStrategy{

	public EstadosEstrategia getEstrategiaCombate() {
		return EstadosEstrategia.DEFENSIVO;
	}
}
