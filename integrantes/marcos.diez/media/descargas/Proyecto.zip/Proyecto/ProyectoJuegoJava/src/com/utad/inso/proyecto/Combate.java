package com.utad.inso.proyecto;

import java.util.Random;
import java.util.Scanner;

/**Combate, sigue el patr�n singelton, ya que en este caso, 
todos los personajes mantienen la misma mec�nica de combate.
*/
public class Combate {
	
	private static Combate combate = new Combate();
	private Scanner scan = new Scanner(System.in);
	
	/**El personaje a atacar� al personaje b*/
	private void atacar(Personajes a, Personajes b) {
		//Danio principal
		Integer danio = a.getFuerza() * a.getArma().getDanio();
		/*
		Resitencia de b es el porcentaje que deniega de da�o
		El danio final es el da�o principal quitandole el porcentaje que le deniega
		*/
		danio = (danio * (100 - b.getResistencia()))/100;
		b.setVida(b.getVida() - danio);
		System.out.print("El personaje "+b.getNombre()+" recibe un danio de "+danio+".");
		//Miramos el estado:
		ContextEstadoPersonaje.aplicarEstado(b, a.getArma().getElementoArma());
	}
	
	/**El personaje b defender� el ataque del a*/
	private void defender(Personajes a, Personajes b) {
		//Danio principal
		Integer danio = a.getFuerza() * a.getArma().getDanio() / 2;
		/*
		El danio final es el da�o principal quitandole el porcentaje que le deniega
		Resitencia de b es el porcentaje que deniega de da�o
		Resistencia de 0 - 100
		*/
		danio = (danio * (100 - b.getResistencia()))/100;
		b.setVida(b.getVida() - danio);
		System.out.print("El personaje "+b.getNombre()+" recibe un danio de "+danio+", porque se ha defendido.");
		//Miramos el estado.
		ContextEstadoPersonaje.aplicarEstado(b, a.getArma().getElementoArma());
	}
	
	/**El personaje b intentar� esquivar el ataque del a*/
	private void esquivar(Personajes a, Personajes b) {
		//Agilidad de 0 - 100
		Random random = new Random();
		int value = random.nextInt(100);
		boolean esquiva = value <= b.getAgilidad();
		if(!esquiva) {
			System.out.println("El personaje "+ b.getNombre() +" no tuvo exito al esquivar");
			atacar(a,b);
		}
		else {
			System.out.println("El personaje "+ b.getNombre() +" tuvo exito al esquivar");
		}
		
	}
	
	/**Segun el estado del personaje se le quitara la vida que le corresponda*/
	private void quitarVida(Personajes a) {
		Integer danio = 0;
		if(a.getEstado().getVidaPerdida()>0) {
			System.out.println("El estado del personaje "+ a.getNombre() +" es "+a.getEstado().name() +". "+
				"Por lo que se le anaide " + a.getEstado().getVidaPerdida() + " de danio.");
		}
		danio += a.getEstado().getVidaPerdida();
		
		a.setVida(a.getVida() - danio);
	}
	
	/**Traduce un valor integer al Enum ECombate retornandolo*/
	private ECombate integerToECombate(Integer movimiento) {
		ECombate emovimento = ECombate.ATACAR;
		switch(movimiento) {
			case 1:
				emovimento = ECombate.ATACAR;
				break;
			case 2:
				emovimento = ECombate.DEFENDER;
				break;
			case 3:
				emovimento = ECombate.ESQUIVAR;
				break;
			default:
				System.out.println("En Combate el swicth de integerToECombate FALLA");
				break;
		}
		return emovimento;
	}
	
	/**Combate entre el PersonajePrincipal y el Enemigo*/
	public boolean combate(PersonajePrincipal pp , Enemigo e) {
		Personajes a = pp, b = e;
		boolean victoria = false;
		Integer vidaInicial = pp.getVida();//Vida para restaurar despues del combate.
		Integer numeroDeTurno = 0;
		establecerQuienEmpiezaAntes(a,b);
		while(a.getVida()>0 && b.getVida()>0){
			System.out.println(a.layout());
			System.out.println(b.layout());
			turnoDeCombate(a,b);

			numeroDeTurno++;
		}
		//Comprobacion de que el personajeprincipal ha ganado
		if(pp.getVida()>0) {
			victoria = true;
			pp.setVida(vidaInicial);
		}
		return victoria;
	}
	
	/**Segun el nivel de agilidad de los dos personajes, empezara el que mas tenga*/
	private void establecerQuienEmpiezaAntes(Personajes a, Personajes b) {
		if(b.getAgilidad() < a.getAgilidad()) {
			Personajes temp = a;
			a = b;
			b = temp;
		}
	}
	
	/**Turno de Combate entre el personaje a y b*/
	private void turnoDeCombate(Personajes a, Personajes b){
		if(ContextEstadoPersonaje.puedeCombatir(a)) {
			//Miramos el movimiento o accion del personaje a:
			ECombate movimientoDelA = null, movimientoDelB = null;
			//Miro si es personajePrincipal a:
			Integer moveEnemigo = movimientoEnemigo();
			if( a instanceof PersonajePrincipal) {
				movimientoDelA = movimientoPersonajePrincipal();
				movimientoDelB = ((Enemigo) b).getMovimientos().get(moveEnemigo);
			}
			else {
				movimientoDelA = ((Enemigo) a).getMovimientos().get(moveEnemigo);
				movimientoDelB = movimientoPersonajePrincipal();
			}
			//A ACTUA:
			switch(movimientoDelA) {
				case ATACAR:
					if(movimientoDelB.equals(ECombate.DEFENDER)) {
						defender(a,b);
					}
					else if(movimientoDelB.equals(ECombate.ESQUIVAR)) {
						esquivar(a,b);
					}
					else {
						atacar(a,b);
						if(ContextEstadoPersonaje.puedeCombatir(b)) {
							atacar(b,a);
						}
					}
					break;
				case DEFENDER:
					if(movimientoDelB.equals(ECombate.ATACAR) && ContextEstadoPersonaje.puedeCombatir(b)) {
						defender(b,a);
					}
					else {
						System.out.println(b.getNombre()+" no ha podido combatir, porque estaba "+movimientoDelB);
					}
					break;
				case ESQUIVAR:
					if(movimientoDelB.equals(ECombate.ATACAR) && ContextEstadoPersonaje.puedeCombatir(b)) {
						esquivar(b,a);
					}
					else {
						System.out.println(b.getNombre()+" no ha podido combatir, porque estaba "+movimientoDelB);
					}
					break;
				default:
					System.out.println("Problema con el movimiento de A en turnoDeCombate");
			}
			//Quitamos vida en caso del estado del personaje:
			quitarVida(a);
			quitarVida(b);
			
			//Quitamos estado:
			ContextEstadoPersonaje.intentarQuitarEstado(a);
			ContextEstadoPersonaje.intentarQuitarEstado(b);
		}
		else {
			System.out.println(a.getNombre()+" no puede combatir.");
		}
	}
	
	/**Pide el movimiento del PersonajePrincipal por consola  
	 * y devuelve el movimiento elegido*/
	private ECombate movimientoPersonajePrincipal() {
		//menu seleccion de acci�n
		Integer control;
		System.out.println("Que quiere hacer: \n"
				+ "1.Atacar\n"
				+ "2.Defensa\n"
				+ "3.Esquivar\n");
		control = scan.nextInt();
		return integerToECombate(control);
	}
	
	/**Al haber 3 tipos de movimientos, se devuelve un n�mero random del 1 al 3*/
	private Integer movimientoEnemigo() {
		int max = 3, min = 0;
		Random random = new Random();
		Integer movimiento = random.nextInt(max + min) + min;
		return movimiento;
	}
	
	/**Metodo singleton que devuelve el combate*/
	public static Combate getInstance() {
		return Combate.combate;
	}
}
