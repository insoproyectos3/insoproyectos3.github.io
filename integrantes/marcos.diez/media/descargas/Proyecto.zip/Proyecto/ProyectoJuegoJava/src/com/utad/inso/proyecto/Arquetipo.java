package com.utad.inso.proyecto;

public enum Arquetipo {
	FUERTE,
	AGIL,
	EQUILIBRADO
}
