package com.utad.inso.proyecto;

public interface ArmaDecorator extends Arma{
	public Arma getArma();
	public void setArma(Arma arma);
}
