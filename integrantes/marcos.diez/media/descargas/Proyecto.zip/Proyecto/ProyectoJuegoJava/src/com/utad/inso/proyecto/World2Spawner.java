package com.utad.inso.proyecto;
import java.util.Random;
public class World2Spawner implements DemonWitchGhostAbstractFactory,AbstractEnemySpawnerFactory {
	private Arma armaDemonio;
	private Arma armaBruja;
	private Arma armaFantasma;
	private	Random rand=new Random();
	private	Integer random;
	private EstadosEstrategia estrategiaActual;
	
	World2Spawner(){
		super();
	}

	public void setArmas(Arma armaDemonio,Arma armaBruja,Arma armaFantasma) {
		this.armaDemonio=armaDemonio;
		this.armaBruja=armaBruja;
		this.armaFantasma=armaFantasma;
	}
	public void setArmaDemonio(Arma arma) {
		this.armaDemonio=arma;
	}
	public void setArmaBruja(Arma arma) {
		this.armaBruja=arma;
	}
	public void setArmaFantasma(Arma arma) {
		this.armaFantasma=arma;
	}

	public Demonio createDemon() {
		random=rand.nextInt(100);
		if(random<=30)
			estrategiaActual = EstadosEstrategia.AGRESIVO;
		else if (random>30 && random <=60)
			estrategiaActual = EstadosEstrategia.DEFENSIVO;
		else
			estrategiaActual = EstadosEstrategia.NEUTRAL;
		return new Demonio("Demonio Ardiente",Estadisticas.Demonio.getResistencia()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Demonio.getVida()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Demonio.getAgilidad()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Demonio.getFuerza()*MultiplicadorMundos.Mundo2.getMultiplicador(), estrategiaActual,armaDemonio);	
	}

	public Bruja createWitch() {
		random=rand.nextInt(100);
		if(random<=30)
			estrategiaActual = EstadosEstrategia.AGRESIVO;
		else if (random>30 && random <=60)
			estrategiaActual = EstadosEstrategia.DEFENSIVO;
		else
			estrategiaActual = EstadosEstrategia.NEUTRAL;
		return new Bruja("Bruja Malvada",Estadisticas.Bruja.getResistencia()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Bruja.getVida()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Bruja.getAgilidad()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Bruja.getFuerza()*MultiplicadorMundos.Mundo2.getMultiplicador(),estrategiaActual,armaBruja);
	}

	public Fantasma createGhost() {
		random=rand.nextInt(100);
		if(random<=30)
			estrategiaActual = EstadosEstrategia.AGRESIVO;
		else if (random>30 && random <=60)
			estrategiaActual = EstadosEstrategia.DEFENSIVO;
		else
			estrategiaActual = EstadosEstrategia.NEUTRAL;
			return new Fantasma("Casper",Estadisticas.Fantasma.getResistencia()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Fantasma.getVida()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Fantasma.getAgilidad()*MultiplicadorMundos.Mundo2.getMultiplicador(),Estadisticas.Fantasma.getFuerza()*MultiplicadorMundos.Mundo2.getMultiplicador(),estrategiaActual,armaFantasma);
	}
	public Enemigo createEnemy() {
		random=rand.nextInt(100);
		if(random<=30)
			return createDemon();
		else if (random>30 && random <=60)
			return createWitch();
		else
			return createGhost();
	}
}
