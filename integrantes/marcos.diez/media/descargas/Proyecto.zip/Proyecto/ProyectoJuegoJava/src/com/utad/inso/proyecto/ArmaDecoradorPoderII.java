package com.utad.inso.proyecto;

public class ArmaDecoradorPoderII implements ArmaDecorator{

	private Integer danio;
	private String descripcion;
	private Arma armaDecorador;
	private ElementoArma elemento;
	
	
	public ArmaDecoradorPoderII(Arma arma,String descripcion,Integer danio,ElementoArma elemento) {
		this.armaDecorador = arma;
		this.danio = danio;
		this.descripcion = descripcion;
		this.elemento = elemento;
	}
	
	public String getDescripcion() {	
		return	"["+this.descripcion+"]";
	}

	public Integer getDanio() {
		return this.danio;
	}

	public Arma getArma() {
		return this.armaDecorador;
	}

	public void setArma(Arma arma) {
		this.armaDecorador = arma;
	}

	public ElementoArma getElementoArma() {
		return this.elemento;
	}

}
