package com.utad.inso.proyecto;

public interface EnemigoTemplate {
	public void combate();
}
