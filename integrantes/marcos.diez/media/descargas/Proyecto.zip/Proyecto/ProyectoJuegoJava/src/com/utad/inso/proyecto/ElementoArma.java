package com.utad.inso.proyecto;

public enum ElementoArma {
	HIELO,
	SUENIO,
	ELECTRICO,
	FUEGO,
	VENENO,
	BASICO;
}
