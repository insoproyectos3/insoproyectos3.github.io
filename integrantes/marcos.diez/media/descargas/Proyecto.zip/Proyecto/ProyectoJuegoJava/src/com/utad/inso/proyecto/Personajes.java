package com.utad.inso.proyecto;


public interface Personajes {
	public String getNombre();
	public Integer getVida();
	public void setVida(Integer vida);
	public Integer getAgilidad();
	public Integer getFuerza();
	public Integer getResistencia();
	public Estado getEstado();
	public void setEstado(Estado estado);
	public Arma getArma();
	public Integer getTurnosEstadoAplicado();
	public void setTurnosEstadoAplicado(Integer turnosEstadoAplicado);
	public String layout();
}
