package com.utad.inso.proyecto;

public enum Estado {
		PERFECTO(0,0),
		SANGRADO(9,10),
		PARALIZADO(7,0),
		QUEMADO(10,15),
		ENVENENADO(5,12),
		CONGELADO(3,0),
		DORMIDO(1,0);
	
	private final Integer probInbuir;
	private final Integer vidaPerdida;
	
	private Estado(Integer probInbuir,Integer vidaPerdida) {
		this.probInbuir = probInbuir;
		this.vidaPerdida = vidaPerdida;
	}
	
	public Integer getProbInbuir() {
		return this.probInbuir;
	}
	
	public Integer getVidaPerdida() {
		return this.vidaPerdida;
	}
	
	
}
