package com.utad.inso.proyecto;

public enum MultiplicadorMundos {
	Mundo1(1),Mundo2(2),Mundo3(3);
	
	private MultiplicadorMundos(Integer multiplicador) {
		this.multiplicador = multiplicador;
	}
	
	private final Integer multiplicador;

	public Integer getMultiplicador() {
		return multiplicador;
	}
}
