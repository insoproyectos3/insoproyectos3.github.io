package com.utad.inso.proyecto;
import java.util.Random;

public class ContextEstadoPersonaje {

	
	//Estado por defecto (neutral):
	private static Estado estadoPerfecto = Estado.PERFECTO;
	//Estados de condici�n:
	private static Estado estadoSangrado = Estado.SANGRADO;
	private static Estado estadoParalizado = Estado.PARALIZADO;
	private static Estado estadoQuemado = Estado.QUEMADO;
	private static Estado estadoEnvenenado = Estado.ENVENENADO;
	private static Estado estadoCongelado = Estado.CONGELADO;
	private static Estado estadoDormido = Estado.DORMIDO;
	
	private static Random random = new Random();
	
	private ContextEstadoPersonaje() {
	
	}
		
	//--------------------------------------------------
	
	public static boolean puedeCombatir(Personajes personaje) {
		boolean par = true;
		if(personaje.getVida()>0) {
			switch(personaje.getEstado()) {
				case CONGELADO:case DORMIDO:case PARALIZADO:{
					System.out.println("El personaje "+personaje.getNombre()+" no puede atacar por que esta "+personaje.getEstado());
					par = false;
				}
				default:{
					
				}
			}
		}else {
			par = false;
		}
		
		return par;			
	}
	
	//--------------------------------------------------
	

	//la miga
    public static void aplicarEstado(Personajes personaje,ElementoArma estado) {
    	
    	Estado estadoAplicado = ElementoAEstado(estado);
    	//Comprobaci�n si ya tiene estado
    	if(personaje.getEstado()!=estadoPerfecto) {
    		System.out.println("DEBUG - No se puede infringir un nuevo estado porque ya esta bajo los efectos");
    	}
    	else{
    		
    		switch(estadoAplicado) {
            
        	case SANGRADO:
        		if(probabilidadInbuir(estadoAplicado)) 
        			personaje.setEstado(estadoSangrado);
        		break;
			case CONGELADO:
				if(probabilidadInbuir(estadoAplicado))
					personaje.setEstado(estadoCongelado);
				break;
			case DORMIDO:
				if(probabilidadInbuir(estadoAplicado))
					personaje.setEstado(estadoDormido);
				break;
			case ENVENENADO:
				if(probabilidadInbuir(estadoAplicado))
					personaje.setEstado(estadoEnvenenado);
				break;
			case PARALIZADO:
				if(probabilidadInbuir(estadoAplicado))
					personaje.setEstado(estadoParalizado);
				break;
			case QUEMADO:
				if(probabilidadInbuir(estadoAplicado))
					personaje.setEstado(estadoQuemado);
				break;
			default:
				break;
				
    		}	
    	}	
    }
    
   
    private static Estado ElementoAEstado(ElementoArma elemento) {
    	Estado estado = Estado.PERFECTO;
    	
    	switch(elemento) {
    	
    	case BASICO:{
    		estado = Estado.PERFECTO;
    		break;
    	}
    	case ELECTRICO:{
    		estado = Estado.PARALIZADO;
    	}
    	case FUEGO:{
    		estado = Estado.QUEMADO;
    	}
    	case HIELO:{
    		estado = Estado.CONGELADO;
    	}
    	case SUENIO:{
    		estado = Estado.DORMIDO;
    	}
    	case VENENO:{
    		estado = Estado.ENVENENADO;
    	}
    	}
    	return estado;
    }
    
        
    private static boolean probabilidadInbuir(Estado state) {
    	
        int value = random.nextInt(10 + 1);
        
        boolean infringe = false;
    	
    	if(value <= state.getProbInbuir()){
    		infringe = true;
    		System.out.println("DEBUG - Se ha infringido: "+state);
    	}else {
    		infringe = false;
    		System.out.println("DEBUG - No se pudo infringir: "+state);
    	}
    	return infringe;
   }
   
    
    public static void intentarQuitarEstado(Personajes personaje) {
    	
    	int porcentaje = random.nextInt(100)+ 1;
    	boolean quitar = false;

    	if(personaje.getEstado()!=Estado.PERFECTO) {
    		personaje.setTurnosEstadoAplicado(personaje.getTurnosEstadoAplicado()+1);

    		if(personaje.getTurnosEstadoAplicado()==4)//100%
    			quitar=true;
    			
    		else if((personaje.getTurnosEstadoAplicado()==3)&&(porcentaje <= 75))
    			quitar=true;//75%
    		
    		else if((personaje.getTurnosEstadoAplicado()==2)&&(porcentaje <= 50))
    			quitar=true;//50%
    		
    		else if((personaje.getTurnosEstadoAplicado()==1)&&(porcentaje <= 25))
    			quitar=true;//25%
    		
    		if(quitar){
    			personaje.setEstado(estadoPerfecto);
    			System.out.println("DEBUG - Se te ha quitado el estado en el turno: "+personaje.getTurnosEstadoAplicado());
    			personaje.setTurnosEstadoAplicado(0);
    		}else {
    			System.out.println("DEBUG - Sigues afectado con una cantidad de: "+personaje.getTurnosEstadoAplicado()+" turnos.");
    		}

    	}
    				
	}
}
