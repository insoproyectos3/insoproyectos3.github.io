package com.utad.inso.proyecto;

public interface AbstractEnemySpawnerFactory {
	public Enemigo createEnemy();
}
