package com.utad.inso.proyecto;

public enum EstadosEstrategia {
	AGRESIVO(0.7,0.3), 
	DEFENSIVO(0.3,0.7),
	NEUTRAL(0.5,0.5);
	
	private Double ataque;
	private Double defensa;
	
	EstadosEstrategia(Double ataque, Double defensa) {
		this.setAtaque(ataque);
		this.setDefensa(defensa);
	}
	public Double getAtaque() {
		return ataque;
	}
	public void setAtaque(Double ataque) {
		this.ataque = ataque;
	}
	public Double getDefensa() {
		return defensa;
	}
	public void setDefensa(Double defensa) {
		this.defensa = defensa;
	}
}
