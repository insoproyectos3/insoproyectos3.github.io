package com.utad.inso.proyecto;

public interface DemonWitchGhostAbstractFactory {
	public Demonio createDemon();
	public Bruja createWitch();
	public Fantasma createGhost();
	public void setArmas(Arma armaDemonio,Arma armaBruja,Arma armaFantasma);
	public void setArmaDemonio(Arma arma);
	public void setArmaBruja(Arma arma);
	public void setArmaFantasma(Arma arma);
}
