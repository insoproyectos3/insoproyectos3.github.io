package com.utad.inso.proyecto;

public class ArmaEstandar implements Arma{
	private Integer danio;
	private String descripcion;
	private ElementoArma elemento;
	
	public ArmaEstandar(String descripcion,Integer danio,ElementoArma elemento) {
		this.danio = danio;
		this.descripcion = descripcion;
		this.elemento = elemento;
	}

	public String getDescripcion() {
		return "["+this.descripcion+"]";
	}

	public Integer getDanio() {
		return this.danio;
	}

	public ElementoArma getElementoArma() {
		return this.elemento;
	}

}
