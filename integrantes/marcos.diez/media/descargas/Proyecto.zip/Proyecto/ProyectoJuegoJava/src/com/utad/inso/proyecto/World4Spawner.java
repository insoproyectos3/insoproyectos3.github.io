package com.utad.inso.proyecto;

public class World4Spawner implements AbstractEnemySpawnerFactory {

	private Arma armaBoss;
	
	public World4Spawner() {
		armaBoss = new ArmaEstandar("Palo",20,ElementoArma.BASICO);
		armaBoss = new ArmaDecoradorPoderII(armaBoss, "Palo duro", 21, ElementoArma.SUENIO);
	}

	public Enemigo createEnemy() {
		return new Ogro( "Estefani",  100, 500, 20, 30, EstadosEstrategia.AGRESIVO,armaBoss );
		
	}

	
}
