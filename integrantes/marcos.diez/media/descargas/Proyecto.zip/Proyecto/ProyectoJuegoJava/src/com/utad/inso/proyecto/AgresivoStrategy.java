package com.utad.inso.proyecto;

public class AgresivoStrategy implements EstartegiasCombateStrategy {

	public EstadosEstrategia getEstrategiaCombate() {
		return EstadosEstrategia.AGRESIVO;
	}
}
